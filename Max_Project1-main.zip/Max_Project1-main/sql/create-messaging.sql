create table IF NOT EXISTS messaging
(
    messaging_id     INTEGER not null
    primary key autoincrement,
    username    TEXT

);